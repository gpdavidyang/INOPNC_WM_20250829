'use client'
import React from 'react'
import Script from 'next/script'

export default function SignupPage() {
  return (
    <div>
      {/* Page-specific styles from original */}
      <style>
        /* 회원가입 페이지 전용 스타일 */
        body {
            margin: 0;
            padding: 0;
            background: #FFFFFF;
            font-family: 'Noto Sans KR', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
        }

        .signup-container {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 16px;
            background: #FFFFFF;
        }

        .signup-content {
            width: 100%;
            max-width: 400px;
            padding: 32px 24px;
            box-sizing: border-box;
        }

        .signup-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 24px;
        }

        .signup-logo {
            height: 30px !important;
            width: auto !important;
            object-fit: contain !important;
            max-width: 100% !important;
            display: block !important;
            flex-shrink: 0 !important;
            visibility: visible !important;
            opacity: 1 !important;
            background: transparent !important;
            position: relative !important;
            z-index: 1 !important;
        }

        .signup-title {
            font-size: 20px;
            font-weight: 600;
            color: #1A254F;
            margin: 0;
            line-height: 1.2;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-input {
            width: 100%;
            height: 45px;
            padding: 0 16px;
            border: 1px solid #E6ECF4;
            border-radius: 10px;
            background: #FFFFFF;
            color: #1A1A1A;
            font-size: 14px;
            transition: all 0.2s ease;
            line-height: 1.5;
            box-sizing: border-box;
            display: flex;
            align-items: center;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--tag-blue);
            box-shadow: 0 0 0 3px var(--tag-blue-20);
        }

        .form-input::placeholder {
            color: #6B7280;
        }

        .email-wrapper {
            display: flex;
            align-items: center;
            gap: 6px;
            height: 45px;
        }

        .email-input {
            flex: 1;
            height: 45px;
            padding: 0 12px;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            box-sizing: border-box;
            display: flex;
            align-items: center;
        }

        .email-at {
            color: #6B7280;
            font-size: 14px;
            font-weight: 500;
            height: 45px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }

        .email-domain-wrapper {
            position: relative;
            flex: 1;
            min-width: 0;
            height: 45px;
        }

        .email-domain-input {
            width: 100%;
            height: 45px;
            padding: 0 12px;
            padding-right: 25px;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            box-sizing: border-box;
            display: flex;
            align-items: center;
        }

        .dropdown-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 14px;
            height: 14px;
            color: #6B7280;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .dropdown-icon.active {
            transform: translateY(-50%) rotate(180deg);
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: #FFFFFF;
            border: 1px solid #E6ECF4;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
            display: none;
        }

        .dropdown-menu.show {
            display: block;
        }

        .dropdown-item {
            padding: 12px 16px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            font-size: 14px;
            color: #1A1A1A;
        }

        .dropdown-item:hover {
            background-color: #F8FAFC;
        }

        .dropdown-item:first-child {
            border-radius: 8px 8px 0 0;
        }

        .dropdown-item:last-child {
            border-radius: 0 0 8px 8px;
        }

        .checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            margin: 24px 0;
        }

        .checkbox input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--tag-blue);
            cursor: pointer;
        }

        .checkbox label {
            font-size: 13px;
            color: #1A1A1A;
            cursor: pointer;
        }

        .submit-button {
            width: 100%;
            height: 45px;
            padding: 0 16px;
            background: #1A254F;
            color: #FFFFFF;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .submit-button:hover {
            background: #0F1A3A;
            transform: translateY(-1px);
        }

        .login-link {
            text-align: center;
            font-size: 14px;
            color: #6B7280;
        }

        .login-link a {
            color: #1A254F;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        .login-link a:hover {
            color: #0068FE;
            text-decoration: underline;
        }

        /* 반응형 디자인 */
        @media (max-width: 480px) {
            .signup-container {
                padding: 12px;
            }
            
            .signup-content {
                padding: 24px 16px;
                max-width: 100%;
                width: calc(100% - 24px);
            }
            
            .signup-title {
                font-size: 22px;
            }
            
            .signup-logo {
                height: 35px;
                width: auto;
                max-width: 100%;
            }
            
            .form-input {
                height: 45px;
                padding: 0 12px;
                font-size: 14px;
                box-sizing: border-box;
            }
            
            .email-wrapper {
                flex-direction: row;
                gap: 8px;
                height: 45px;
            }
            
            .email-at {
                display: flex;
                height: 45px;
            }
            
            .email-input,
            .email-domain-input {
                height: 45px;
                white-space: normal;
                overflow: visible;
                text-overflow: initial;
            }
            
            .submit-button {
                height: 45px;
                font-size: 14px;
            }
        }

        @media (max-width: 360px) {
            .signup-container {
                padding: 8px;
            }
            
            .signup-content {
                padding: 20px 12px;
                width: calc(100% - 16px);
            }
            
            .signup-title {
                font-size: 20px;
            }
            
            .signup-logo {
                height: 35px;
                width: auto;
                max-width: 100%;
            }
            
            .form-input {
                height: 45px;
                padding: 0 10px;
                font-size: 14px;
            }
            
            .email-wrapper {
                gap: 8px;
                height: 45px;
            }
            
            .email-input,
            .email-domain-input {
                height: 45px;
            }
            
            .email-at {
                height: 45px;
            }
            
            .submit-button {
                height: 45px;
                font-size: 14px;
            }
        }

        /* 접근성 */
        @media (prefers-reduced-motion: reduce) {
            .submit-button,
            .form-input {
                transition: none;
            }
            
            .submit-button:hover {
                transform: none;
            }
        }

        /* 포커스 표시 */
        .form-input:focus-visible,
        .submit-button:focus-visible,
        .checkbox:focus-visible {
            outline: 2px solid var(--tag-blue);
            outline-offset: 2px;
        }
    </style>
      {/* Original body markup injected 1:1 */}
      <div dangerouslySetInnerHTML={{__html: `<div class="signup-container">
        <div class="signup-content">
            <div class="signup-header">
            <img src="images/logo_main.png" 
                 alt="INOPNC 로고" 
                 class="signup-logo"
                 style="height: 35px; width: auto; object-fit: contain; display: block !important;"
                 onload="console.log('회원가입 로고 이미지 로드 성공'); this.style.display='block';"
                 onerror="console.log('회원가입 로고 이미지 로드 실패'); this.style.display='none';"
                 loading="eager">
                <h1 class="signup-title">회원가입</h1>
            </div>

            <form id="signupForm" class="signup-form">
                <div class="form-group">
                    <input 
                        type="text" 
                        id="name" 
                        class="form-input" 
                        placeholder="이름"
                        required
                        autocomplete="name"
                    >
                </div>

                <div class="form-group">
                    <input 
                        type="text" 
                        id="company" 
                        class="form-input" 
                        placeholder="소속(회사명)"
                        required
                        autocomplete="organization"
                    >
                </div>

                <div class="form-group">
                    <input 
                        type="text" 
                        id="position" 
                        class="form-input" 
                        placeholder="직함"
                        required
                        autocomplete="organization-title"
                    >
                </div>

                <div class="form-group">
                    <input 
                        type="tel" 
                        id="phone" 
                        class="form-input" 
                        placeholder="핸드폰 번호 (예: 010-1234-5678)"
                        required
                        autocomplete="tel"
                        pattern="[0-9-+()\s]+"
                        maxlength="13"
                    >
                </div>

                <div class="form-group">
                    <div class="email-wrapper">
                        <input 
                            type="text" 
                            id="emailUsername" 
                            class="form-input email-input" 
                            placeholder="이메일"
                            required
                            autocomplete="username"
                            pattern="[a-zA-Z0-9._%+-]+"
                        >
                        <span class="email-at">@</span>
                        <div class="email-domain-wrapper">
                            <input 
                                type="text" 
                                id="emailDomain" 
                                class="form-input email-domain-input" 
                                placeholder="직접입력"
                                required
                                pattern="[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
                            >
                            <svg class="dropdown-icon" id="dropdownIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6,9 12,15 18,9"></polyline>
                            </svg>
                            <div class="dropdown-menu" id="dropdownMenu">
                                <div class="dropdown-item" data-domain="gmail.com">gmail.com</div>
                                <div class="dropdown-item" data-domain="naver.com">naver.com</div>
                                <div class="dropdown-item" data-domain="daum.net">daum.net</div>
                                <div class="dropdown-item" data-domain="hanmail.net">hanmail.net</div>
                                <div class="dropdown-item" data-domain="yahoo.com">yahoo.com</div>
                                <div class="dropdown-item" data-domain="hotmail.com">hotmail.com</div>
                                <div class="dropdown-item" data-domain="outlook.com">outlook.com</div>
                                <div class="dropdown-item" data-domain="nate.com">nate.com</div>
                                <div class="dropdown-item" data-domain="kakao.com">kakao.com</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="checkbox">
                    <input type="checkbox" id="agreeTerms" name="agreeTerms" checked required>
                    <label for="agreeTerms">이용약관 및 개인정보처리방침에 동의합니다</label>
                </div>

                <button type="submit" class="submit-button" id="submitButton">
                    승인요청
                </button>
            </form>

        </div>
    </div>

    <script>
        // 입력 양식 검증 함수들
        function validateName(name) {
            return /^[가-힣a-zA-Z\s]{2,20}$/.test(name);
        }

        function validatePhone(phone) {
            return /^01[0-9]-?[0-9]{3,4}-?[0-9]{4}$/.test(phone);
        }

        function validateEmailUsername(username) {
            return /^[a-zA-Z0-9._%+-]+$/.test(username);
        }

        function validateEmailDomain(domain) {
            return /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(domain);
        }

        // 핸드폰 번호 자동 포맷팅
        document.getElementById('phone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            if (value.length >= 11) {
                value = value.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
            } else if (value.length >= 7) {
                value = value.replace(/(\d{3})(\d{4})/, '$1-$2');
            } else if (value.length >= 3) {
                value = value.replace(/(\d{3})/, '$1-');
            }
            e.target.value = value;
        });

        // 회원가입 폼 처리
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const company = document.getElementById('company').value.trim();
            const position = document.getElementById('position').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const emailUsername = document.getElementById('emailUsername').value.trim();
            const emailDomain = document.getElementById('emailDomain').value.trim();
            const agreeTerms = document.getElementById('agreeTerms').checked;
            const submitButton = document.getElementById('submitButton');
            
            // 입력 양식 검증
            if (!validateName(name)) {
                showNotification('이름은 2-20자의 한글 또는 영문으로 입력해주세요.', 'error');
                return;
            }
            
            if (!validatePhone(phone)) {
                showNotification('핸드폰 번호는 010-1234-5678 형식으로 입력해주세요.', 'error');
                return;
            }
            
            if (!validateEmailUsername(emailUsername)) {
                showNotification('이메일 아이디는 영문, 숫자, 특수문자(._%+-)만 사용 가능합니다.', 'error');
                return;
            }
            
            if (!validateEmailDomain(emailDomain)) {
                showNotification('이메일 도메인을 올바르게 입력해주세요.', 'error');
                return;
            }
            
            if (!agreeTerms) {
                showNotification('이용약관 및 개인정보처리방침에 동의 후 가입이 가능합니다.', 'error');
                return;
            }
            
            // 로딩 상태 표시
            submitButton.textContent = '처리 중...';
            submitButton.disabled = true;
            
            // 실제 회원가입 로직 (여기서는 시뮬레이션)
            setTimeout(() => {
                const email = emailUsername + '@' + emailDomain;
                
                // 회원 정보를 로컬 스토리지에 저장 (승인 대기 상태)
                const userData = {
                    name: name,
                    company: company,
                    position: position,
                    phone: phone,
                    email: email,
                    signupTime: new Date().toISOString(),
                    status: 'pending' // 승인 대기 상태
                };
                
                localStorage.setItem('userName', name);
                localStorage.setItem('userCompany', company);
                localStorage.setItem('userPosition', position);
                localStorage.setItem('userPhone', phone);
                localStorage.setItem('userEmail', email);
                localStorage.setItem('userSignupTime', new Date().toISOString());
                localStorage.setItem('userStatus', 'pending');
                
                // 관리자에게 회원가입 신청 메일 발송
                sendSignupRequestEmail(userData);
                
                // 승인 대기 메시지
                showNotification('관리자 승인 후 이용가능합니다.', 'info');
                
                // 로그인 페이지로 이동
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 3000);
            }, 2000);
        });

        // 회원가입 신청 메일 발송
        function sendSignupRequestEmail(userData) {
            const emailData = {
                to: 'khy972@inopnc.com',
                subject: '[INOPNC] 회원가입 승인 요청',
                body: \`
새로운 회원가입 신청이 접수되었습니다.

=== 회원 정보 ===
이름: ${userData.name}
소속(회사명): ${userData.company}
직함: ${userData.position}
핸드폰 번호: ${userData.phone}
이메일 주소: ${userData.email}

=== 신청 정보 ===
신청 시간: ${new Date(userData.signupTime).toLocaleString('ko-KR')}
상태: 승인 대기

관리자 콘솔에서 승인 처리를 진행해주세요.
승인 후 사용자에게 문자 알림이 발송됩니다.

이 알림은 시스템에서 자동으로 발송되었습니다.
                \`.trim()
            };

            // 실제 구현에서는 서버 API를 통해 메일 발송
            // 여기서는 시뮬레이션으로 로컬 스토리지에 저장
            const emailLog = JSON.parse(localStorage.getItem('emailLog') || '[]');
            emailLog.push({
                ...emailData,
                timestamp: new Date().toISOString(),
                status: 'sent',
                type: 'signup_request'
            });
            localStorage.setItem('emailLog', JSON.stringify(emailLog));

            // 관리자 콘솔용 데이터 저장
            const adminData = JSON.parse(localStorage.getItem('adminSignupRequests') || '[]');
            adminData.push({
                ...userData,
                requestId: 'REQ_' + Date.now(),
                adminEmail: 'khy972@inopnc.com'
            });
            localStorage.setItem('adminSignupRequests', JSON.stringify(adminData));

            // 콘솔에 메일 내용 출력 (개발용)
            console.log('=== 회원가입 신청 메일 발송 ===');
            console.log('수신자:', emailData.to);
            console.log('제목:', emailData.subject);
            console.log('내용:', emailData.body);
            console.log('발송 시간:', new Date().toLocaleString('ko-KR'));
        }

        // 관리자 승인 처리 함수 (시뮬레이션)
        function approveUser(requestId) {
            const adminData = JSON.parse(localStorage.getItem('adminSignupRequests') || '[]');
            const userData = adminData.find(req => req.requestId === requestId);
            
            if (userData) {
                // 승인 상태로 변경
                userData.status = 'approved';
                userData.approvedTime = new Date().toISOString();
                localStorage.setItem('adminSignupRequests', JSON.stringify(adminData));
                
                // 사용자에게 승인 완료 알림 발송
                sendApprovalNotification(userData);
                
                console.log('사용자 승인 완료:', userData.name);
            }
        }

        // 승인 완료 알림 발송 (이메일/문자)
        function sendApprovalNotification(userData) {
            // 이메일 알림
            const emailData = {
                to: userData.email,
                subject: '[INOPNC] 회원가입 승인 완료',
                body: \`
안녕하세요 ${userData.name}님,

INOPNC 회원가입이 승인되었습니다.

=== 승인 정보 ===
이름: ${userData.name}
소속: ${userData.company}
직함: ${userData.position}
승인 시간: ${new Date().toLocaleString('ko-KR')}

이제 INOPNC 서비스를 이용하실 수 있습니다.
로그인 후 서비스를 이용해주세요.

감사합니다.
INOPNC 관리자
                \`.trim()
            };

            // 문자 알림 (핸드폰 번호로)
            const smsData = {
                to: userData.phone,
                message: \`[INOPNC] ${userData.name}님, 회원가입이 승인되었습니다. 이제 서비스를 이용하실 수 있습니다.\`
            };

            // 로그 저장
            const notificationLog = JSON.parse(localStorage.getItem('notificationLog') || '[]');
            notificationLog.push({
                type: 'approval',
                email: emailData,
                sms: smsData,
                timestamp: new Date().toISOString(),
                status: 'sent'
            });
            localStorage.setItem('notificationLog', JSON.stringify(notificationLog));

            console.log('=== 승인 완료 알림 발송 ===');
            console.log('이메일 수신자:', emailData.to);
            console.log('문자 수신자:', smsData.to);
            console.log('이메일 제목:', emailData.subject);
            console.log('문자 내용:', smsData.message);
        }

        // 개발용: 모든 승인 대기 사용자 승인 처리
        function approveAllPendingUsers() {
            const adminData = JSON.parse(localStorage.getItem('adminSignupRequests') || '[]');
            const pendingUsers = adminData.filter(req => req.status === 'pending');
            
            pendingUsers.forEach(user => {
                approveUser(user.requestId);
            });
            
            console.log(\`${pendingUsers.length}명의 사용자가 승인되었습니다.\`);
        }

        // 개발용: 승인 처리 버튼 (실제 구현에서는 관리자 콘솔에서 처리)
        if (window.location.search.includes('admin=true')) {
            const adminButton = document.createElement('button');
            adminButton.textContent = '모든 대기 사용자 승인';
            adminButton.style.cssText = \`
                position: fixed;
                top: 20px;
                left: 20px;
                background: #1A254F;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 8px;
                cursor: pointer;
                z-index: 10000;
            \`;
            adminButton.onclick = approveAllPendingUsers;
            document.body.appendChild(adminButton);
        }

        // 이메일 도메인 드롭다운 기능
        const dropdownIcon = document.getElementById('dropdownIcon');
        const dropdownMenu = document.getElementById('dropdownMenu');
        const emailDomainInput = document.getElementById('emailDomain');

        // 드롭다운 토글
        dropdownIcon.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleDropdown();
        });

        // 드롭다운 메뉴 항목 클릭
        dropdownMenu.addEventListener('click', function(e) {
            if (e.target.classList.contains('dropdown-item')) {
                const domain = e.target.getAttribute('data-domain');
                emailDomainInput.value = domain;
                closeDropdown();
            }
        });

        // 입력 필드 포커스 시 드롭다운 열기
        emailDomainInput.addEventListener('focus', function() {
            openDropdown();
        });

        // 이미지 로딩 확인 및 디버깅
        function checkSignupImageLoad() {
            const logo = document.querySelector('.signup-logo');
            if (logo) {
                console.log('회원가입 로고 요소 찾음:', logo);
                console.log('이미지 src:', logo.src);
                console.log('이미지 완료 상태:', logo.complete);
                console.log('이미지 자연 크기:', logo.naturalWidth, 'x', logo.naturalHeight);
                
                if (logo.complete && logo.naturalHeight !== 0) {
                    console.log('회원가입 이미지가 이미 로드됨');
                    logo.style.display = 'block';
                } else {
                    console.log('회원가입 이미지 로딩 중...');
                    // 이미지 재로딩 시도
                    setTimeout(() => {
                        if (!logo.complete || logo.naturalHeight === 0) {
                            console.log('이미지 재로딩 시도');
                            const originalSrc = logo.src.split('&t=')[0];
                            logo.src = originalSrc + '&t=' + Date.now();
                        }
                    }, 2000);
                }
            } else {
                console.log('회원가입 로고 요소를 찾을 수 없음');
            }
        }
        
        function forceImageReload() {
            const logo = document.querySelector('.signup-logo');
            if (logo) {
                const baseUrl = 'images/logo_n.png';
                logo.src = baseUrl + '?t=' + Date.now();
                console.log('강제 이미지 재로딩:', logo.src);
            }
        }

        // 페이지 로드 후 이미지 상태 확인
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(checkSignupImageLoad, 1000);
            
            // 이미지 로딩 실패 시 재시도
            const logo = document.querySelector('.signup-logo');
            if (logo) {
                logo.addEventListener('error', function() {
                    console.log('이미지 로딩 실패, 재시도 중...');
                    setTimeout(forceImageReload, 1000);
                });
                
                logo.addEventListener('load', function() {
                    console.log('이미지 로딩 성공 확인됨');
                    this.style.display = 'block';
                });
            }
        });

        // 외부 클릭 시 드롭다운 닫기
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.email-domain-wrapper')) {
                closeDropdown();
            }
        });

        // 드롭다운 열기
        function openDropdown() {
            dropdownMenu.classList.add('show');
            dropdownIcon.classList.add('active');
        }

        // 드롭다운 닫기
        function closeDropdown() {
            dropdownMenu.classList.remove('show');
            dropdownIcon.classList.remove('active');
        }

        // 드롭다운 토글
        function toggleDropdown() {
            if (dropdownMenu.classList.contains('show')) {
                closeDropdown();
            } else {
                openDropdown();
            }
        }

        // 알림 표시
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = \`notification notification-${type}\`;
            notification.style.cssText = \`
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: var(--card);
                color: var(--ink);
                padding: 16px 24px;
                border-radius: 12px;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                border: 1px solid var(--line);
                z-index: 10000;
                animation: slideDown 0.3s ease-out;
                max-width: 90vw;
                text-align: center;
                font-size: 14px;
            \`;
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            // 3초 후 자동 제거
            setTimeout(() => {
                notification.style.animation = 'slideUp 0.3s ease-out';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
        }

        // 애니메이션 CSS 추가
        const style = document.createElement('style');
        style.textContent = \`
            @keyframes slideDown {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
            
            @keyframes slideUp {
                from {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
            }
        \`;
        document.head.appendChild(style);

        // 키보드 접근성
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.classList.contains('form-input')) {
                const form = document.getElementById('signupForm');
                const inputs = Array.from(form.querySelectorAll('.form-input'));
                const currentIndex = inputs.indexOf(e.target);
                
                if (currentIndex < inputs.length - 1) {
                    inputs[currentIndex + 1].focus();
                } else {
                    form.dispatchEvent(new Event('submit'));
                }
            }
        });
    </script>`}} />
      {/* Original scripts executed via next/script */}
      <Script id="signup-inline-0" strategy="afterInteractive">{`// 입력 양식 검증 함수들
        function validateName(name) {
            return /^[가-힣a-zA-Z\s]{2,20}$/.test(name);
        }

        function validatePhone(phone) {
            return /^01[0-9]-?[0-9]{3,4}-?[0-9]{4}$/.test(phone);
        }

        function validateEmailUsername(username) {
            return /^[a-zA-Z0-9._%+-]+$/.test(username);
        }

        function validateEmailDomain(domain) {
            return /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(domain);
        }

        // 핸드폰 번호 자동 포맷팅
        document.getElementById('phone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            if (value.length >= 11) {
                value = value.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
            } else if (value.length >= 7) {
                value = value.replace(/(\d{3})(\d{4})/, '$1-$2');
            } else if (value.length >= 3) {
                value = value.replace(/(\d{3})/, '$1-');
            }
            e.target.value = value;
        });

        // 회원가입 폼 처리
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const company = document.getElementById('company').value.trim();
            const position = document.getElementById('position').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const emailUsername = document.getElementById('emailUsername').value.trim();
            const emailDomain = document.getElementById('emailDomain').value.trim();
            const agreeTerms = document.getElementById('agreeTerms').checked;
            const submitButton = document.getElementById('submitButton');
            
            // 입력 양식 검증
            if (!validateName(name)) {
                showNotification('이름은 2-20자의 한글 또는 영문으로 입력해주세요.', 'error');
                return;
            }
            
            if (!validatePhone(phone)) {
                showNotification('핸드폰 번호는 010-1234-5678 형식으로 입력해주세요.', 'error');
                return;
            }
            
            if (!validateEmailUsername(emailUsername)) {
                showNotification('이메일 아이디는 영문, 숫자, 특수문자(._%+-)만 사용 가능합니다.', 'error');
                return;
            }
            
            if (!validateEmailDomain(emailDomain)) {
                showNotification('이메일 도메인을 올바르게 입력해주세요.', 'error');
                return;
            }
            
            if (!agreeTerms) {
                showNotification('이용약관 및 개인정보처리방침에 동의 후 가입이 가능합니다.', 'error');
                return;
            }
            
            // 로딩 상태 표시
            submitButton.textContent = '처리 중...';
            submitButton.disabled = true;
            
            // 실제 회원가입 로직 (여기서는 시뮬레이션)
            setTimeout(() => {
                const email = emailUsername + '@' + emailDomain;
                
                // 회원 정보를 로컬 스토리지에 저장 (승인 대기 상태)
                const userData = {
                    name: name,
                    company: company,
                    position: position,
                    phone: phone,
                    email: email,
                    signupTime: new Date().toISOString(),
                    status: 'pending' // 승인 대기 상태
                };
                
                localStorage.setItem('userName', name);
                localStorage.setItem('userCompany', company);
                localStorage.setItem('userPosition', position);
                localStorage.setItem('userPhone', phone);
                localStorage.setItem('userEmail', email);
                localStorage.setItem('userSignupTime', new Date().toISOString());
                localStorage.setItem('userStatus', 'pending');
                
                // 관리자에게 회원가입 신청 메일 발송
                sendSignupRequestEmail(userData);
                
                // 승인 대기 메시지
                showNotification('관리자 승인 후 이용가능합니다.', 'info');
                
                // 로그인 페이지로 이동
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 3000);
            }, 2000);
        });

        // 회원가입 신청 메일 발송
        function sendSignupRequestEmail(userData) {
            const emailData = {
                to: 'khy972@inopnc.com',
                subject: '[INOPNC] 회원가입 승인 요청',
                body: `
새로운 회원가입 신청이 접수되었습니다.

=== 회원 정보 ===
이름: ${userData.name}
소속(회사명): ${userData.company}
직함: ${userData.position}
핸드폰 번호: ${userData.phone}
이메일 주소: ${userData.email}

=== 신청 정보 ===
신청 시간: ${new Date(userData.signupTime).toLocaleString('ko-KR')}
상태: 승인 대기

관리자 콘솔에서 승인 처리를 진행해주세요.
승인 후 사용자에게 문자 알림이 발송됩니다.

이 알림은 시스템에서 자동으로 발송되었습니다.
                `.trim()
            };

            // 실제 구현에서는 서버 API를 통해 메일 발송
            // 여기서는 시뮬레이션으로 로컬 스토리지에 저장
            const emailLog = JSON.parse(localStorage.getItem('emailLog') || '[]');
            emailLog.push({
                ...emailData,
                timestamp: new Date().toISOString(),
                status: 'sent',
                type: 'signup_request'
            });
            localStorage.setItem('emailLog', JSON.stringify(emailLog));

            // 관리자 콘솔용 데이터 저장
            const adminData = JSON.parse(localStorage.getItem('adminSignupRequests') || '[]');
            adminData.push({
                ...userData,
                requestId: 'REQ_' + Date.now(),
                adminEmail: 'khy972@inopnc.com'
            });
            localStorage.setItem('adminSignupRequests', JSON.stringify(adminData));

            // 콘솔에 메일 내용 출력 (개발용)
            console.log('=== 회원가입 신청 메일 발송 ===');
            console.log('수신자:', emailData.to);
            console.log('제목:', emailData.subject);
            console.log('내용:', emailData.body);
            console.log('발송 시간:', new Date().toLocaleString('ko-KR'));
        }

        // 관리자 승인 처리 함수 (시뮬레이션)
        function approveUser(requestId) {
            const adminData = JSON.parse(localStorage.getItem('adminSignupRequests') || '[]');
            const userData = adminData.find(req => req.requestId === requestId);
            
            if (userData) {
                // 승인 상태로 변경
                userData.status = 'approved';
                userData.approvedTime = new Date().toISOString();
                localStorage.setItem('adminSignupRequests', JSON.stringify(adminData));
                
                // 사용자에게 승인 완료 알림 발송
                sendApprovalNotification(userData);
                
                console.log('사용자 승인 완료:', userData.name);
            }
        }

        // 승인 완료 알림 발송 (이메일/문자)
        function sendApprovalNotification(userData) {
            // 이메일 알림
            const emailData = {
                to: userData.email,
                subject: '[INOPNC] 회원가입 승인 완료',
                body: `
안녕하세요 ${userData.name}님,

INOPNC 회원가입이 승인되었습니다.

=== 승인 정보 ===
이름: ${userData.name}
소속: ${userData.company}
직함: ${userData.position}
승인 시간: ${new Date().toLocaleString('ko-KR')}

이제 INOPNC 서비스를 이용하실 수 있습니다.
로그인 후 서비스를 이용해주세요.

감사합니다.
INOPNC 관리자
                `.trim()
            };

            // 문자 알림 (핸드폰 번호로)
            const smsData = {
                to: userData.phone,
                message: `[INOPNC] ${userData.name}님, 회원가입이 승인되었습니다. 이제 서비스를 이용하실 수 있습니다.`
            };

            // 로그 저장
            const notificationLog = JSON.parse(localStorage.getItem('notificationLog') || '[]');
            notificationLog.push({
                type: 'approval',
                email: emailData,
                sms: smsData,
                timestamp: new Date().toISOString(),
                status: 'sent'
            });
            localStorage.setItem('notificationLog', JSON.stringify(notificationLog));

            console.log('=== 승인 완료 알림 발송 ===');
            console.log('이메일 수신자:', emailData.to);
            console.log('문자 수신자:', smsData.to);
            console.log('이메일 제목:', emailData.subject);
            console.log('문자 내용:', smsData.message);
        }

        // 개발용: 모든 승인 대기 사용자 승인 처리
        function approveAllPendingUsers() {
            const adminData = JSON.parse(localStorage.getItem('adminSignupRequests') || '[]');
            const pendingUsers = adminData.filter(req => req.status === 'pending');
            
            pendingUsers.forEach(user => {
                approveUser(user.requestId);
            });
            
            console.log(`${pendingUsers.length}명의 사용자가 승인되었습니다.`);
        }

        // 개발용: 승인 처리 버튼 (실제 구현에서는 관리자 콘솔에서 처리)
        if (window.location.search.includes('admin=true')) {
            const adminButton = document.createElement('button');
            adminButton.textContent = '모든 대기 사용자 승인';
            adminButton.style.cssText = `
                position: fixed;
                top: 20px;
                left: 20px;
                background: #1A254F;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 8px;
                cursor: pointer;
                z-index: 10000;
            `;
            adminButton.onclick = approveAllPendingUsers;
            document.body.appendChild(adminButton);
        }

        // 이메일 도메인 드롭다운 기능
        const dropdownIcon = document.getElementById('dropdownIcon');
        const dropdownMenu = document.getElementById('dropdownMenu');
        const emailDomainInput = document.getElementById('emailDomain');

        // 드롭다운 토글
        dropdownIcon.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleDropdown();
        });

        // 드롭다운 메뉴 항목 클릭
        dropdownMenu.addEventListener('click', function(e) {
            if (e.target.classList.contains('dropdown-item')) {
                const domain = e.target.getAttribute('data-domain');
                emailDomainInput.value = domain;
                closeDropdown();
            }
        });

        // 입력 필드 포커스 시 드롭다운 열기
        emailDomainInput.addEventListener('focus', function() {
            openDropdown();
        });

        // 이미지 로딩 확인 및 디버깅
        function checkSignupImageLoad() {
            const logo = document.querySelector('.signup-logo');
            if (logo) {
                console.log('회원가입 로고 요소 찾음:', logo);
                console.log('이미지 src:', logo.src);
                console.log('이미지 완료 상태:', logo.complete);
                console.log('이미지 자연 크기:', logo.naturalWidth, 'x', logo.naturalHeight);
                
                if (logo.complete && logo.naturalHeight !== 0) {
                    console.log('회원가입 이미지가 이미 로드됨');
                    logo.style.display = 'block';
                } else {
                    console.log('회원가입 이미지 로딩 중...');
                    // 이미지 재로딩 시도
                    setTimeout(() => {
                        if (!logo.complete || logo.naturalHeight === 0) {
                            console.log('이미지 재로딩 시도');
                            const originalSrc = logo.src.split('&t=')[0];
                            logo.src = originalSrc + '&t=' + Date.now();
                        }
                    }, 2000);
                }
            } else {
                console.log('회원가입 로고 요소를 찾을 수 없음');
            }
        }
        
        function forceImageReload() {
            const logo = document.querySelector('.signup-logo');
            if (logo) {
                const baseUrl = 'images/logo_n.png';
                logo.src = baseUrl + '?t=' + Date.now();
                console.log('강제 이미지 재로딩:', logo.src);
            }
        }

        // 페이지 로드 후 이미지 상태 확인
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(checkSignupImageLoad, 1000);
            
            // 이미지 로딩 실패 시 재시도
            const logo = document.querySelector('.signup-logo');
            if (logo) {
                logo.addEventListener('error', function() {
                    console.log('이미지 로딩 실패, 재시도 중...');
                    setTimeout(forceImageReload, 1000);
                });
                
                logo.addEventListener('load', function() {
                    console.log('이미지 로딩 성공 확인됨');
                    this.style.display = 'block';
                });
            }
        });

        // 외부 클릭 시 드롭다운 닫기
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.email-domain-wrapper')) {
                closeDropdown();
            }
        });

        // 드롭다운 열기
        function openDropdown() {
            dropdownMenu.classList.add('show');
            dropdownIcon.classList.add('active');
        }

        // 드롭다운 닫기
        function closeDropdown() {
            dropdownMenu.classList.remove('show');
            dropdownIcon.classList.remove('active');
        }

        // 드롭다운 토글
        function toggleDropdown() {
            if (dropdownMenu.classList.contains('show')) {
                closeDropdown();
            } else {
                openDropdown();
            }
        }

        // 알림 표시
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: var(--card);
                color: var(--ink);
                padding: 16px 24px;
                border-radius: 12px;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                border: 1px solid var(--line);
                z-index: 10000;
                animation: slideDown 0.3s ease-out;
                max-width: 90vw;
                text-align: center;
                font-size: 14px;
            `;
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            // 3초 후 자동 제거
            setTimeout(() => {
                notification.style.animation = 'slideUp 0.3s ease-out';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
        }

        // 애니메이션 CSS 추가
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideDown {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
            
            @keyframes slideUp {
                from {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
            }
        `;
        document.head.appendChild(style);

        // 키보드 접근성
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.classList.contains('form-input')) {
                const form = document.getElementById('signupForm');
                const inputs = Array.from(form.querySelectorAll('.form-input'));
                const currentIndex = inputs.indexOf(e.target);
                
                if (currentIndex < inputs.length - 1) {
                    inputs[currentIndex + 1].focus();
                } else {
                    form.dispatchEvent(new Event('submit'));
                }
            }
        });`}</Script>
    </div>
  )
}
