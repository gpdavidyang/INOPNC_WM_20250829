import { WorkerData } from './types';

export const WORKER_DATA: WorkerData[] = [
  {
    id: 'w1',
    name: '김철수',
    role: '반장',
    site: '자이 아파트 101동',
    status: 'pending',
    avatarChar: '김',
    details: [
      { label: '오늘 작업', value: '슬라브 균열 보수' },
      { label: '투입 공수', value: '1.0 (08:00~17:00)' },
      { label: '증빙 자료', value: '사진 6장 / 도면 1건', valueColor: '#31a3fa' },
    ],
    actions: ['log', 'approve', 'call']
  },
  {
    id: 'w2',
    name: '박영희',
    role: '팀장',
    site: '삼성 반도체 P3',
    status: 'working',
    avatarChar: '박',
    avatarStyle: { backgroundColor: '#ffe4e6', color: '#e11d48' },
    details: [
      { label: '오늘 작업', value: '배관 용접 및 비파괴 검사' },
      { label: '미조치 하자', value: '3건 (긴급 1건)', valueColor: '#e11d48' },
    ],
    actions: ['defect', 'drawing', 'call']
  },
  {
    id: 'w3',
    name: '이민호',
    role: '기공',
    site: '자이 아파트 103동',
    status: 'working',
    avatarChar: '이',
    details: [
      { label: '오늘 작업', value: '내부 미장 작업' },
      { label: '투입 공수', value: '1.0 (08:00~17:00)' },
    ],
    actions: ['log', 'call']
  },
  {
    id: 'w4',
    name: '최지우',
    role: '관리자',
    site: '삼성 반도체 P4',
    status: 'pending',
    avatarChar: '최',
    avatarStyle: { backgroundColor: '#f0fdf4', color: '#16a34a' },
    details: [
      { label: '오늘 작업', value: '안전 점검 및 순찰' },
      { label: '특이 사항', value: 'A구역 안전난간 보강 필요', valueColor: '#e11d48' },
    ],
    actions: ['approve', 'call', 'defect']
  },
  {
    id: 'w5',
    name: '정우성',
    role: '조공',
    site: '자이 아파트 105동',
    status: 'working',
    avatarChar: '정',
    details: [
      { label: '오늘 작업', value: '자재 운반 및 정리' },
      { label: '투입 공수', value: '1.0 (08:00~17:00)' },
    ],
    actions: ['log', 'call']
  },
  {
    id: 'w6',
    name: '강동원',
    role: '안전감시단',
    site: '삼성 반도체 P3',
    status: 'working',
    avatarChar: '강',
    avatarStyle: { backgroundColor: '#fff7ed', color: '#ea580c' },
    details: [
      { label: '오늘 작업', value: '화기 작업 감시' },
      { label: '작업 위치', value: '3층 배관실' },
    ],
    actions: ['call', 'defect']
  },
  {
    id: 'w7',
    name: '손예진',
    role: '반장',
    site: '자이 아파트 102동',
    status: 'pending',
    avatarChar: '손',
    details: [
      { label: '오늘 작업', value: '타일 부착 작업' },
      { label: '투입 공수', value: '1.0 (08:00~17:00)' },
      { label: '증빙 자료', value: '사진 4장', valueColor: '#31a3fa' },
    ],
    actions: ['log', 'approve', 'call']
  },
  {
    id: 'w8',
    name: '현빈',
    role: '팀장',
    site: '삼성 반도체 P3',
    status: 'working',
    avatarChar: '현',
    details: [
      { label: '오늘 작업', value: '전기 배선 작업' },
      { label: '잔여 작업', value: '메인 분전반 결선' },
    ],
    actions: ['drawing', 'call']
  }
];